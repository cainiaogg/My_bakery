title: Java数组_Unit4
date: 2016-01-26 10:35:11
categories: 从零一起学Java
---

# 数组的创建
<!--more-->
```java
        int[] a = {1, 2, 3},b;
        b = new int[10];
        System.out.printf("%d\n",b.length);
```
int[] 声明一个整型的数组对象
b = new int[10] b申请十个整型大小的空间
a = {1, 2, 3} 直接将a初始化为a[0] = 1,a[1] = 2,a[2] = 3
length 是 b数组的一个属性，表示b这个数组的长度
# 数组的拷贝
## 一个是类似引用
```java
public class Main {
    public static void main(String[] args) {
        int[] a = {1, 2, 3},b = {2, 3, 4};
        a = b;
        a[0] = 8;
        for(int i = 0; i < a.length; i++){
            System.out.printf("%d ",a[i]);
        }
        System.out.println();
        System.out.println(b[0]);//怕你看不见，这里自己看下
    }
}
```
复杂度O(1)
输出结果如下
>8 3 4
>8

## 另一个使用arraycopy函数
>public static void arraycopy(Object src, int srcPos, Object dest, int destPos, int length)

```java
public class Main {
    public static void main(String[] args) {
        int[] a = {1, 2, 3},b = {2, 3, 4};
        System.arraycopy(a,0,b,0,3);
        for(int i = 0; i < a.length; i++){
            System.out.printf("%d ",b[i]);
        }
        System.out.println();
    }
}
```
输出结果如下
>1 2 3 
arraycopy(a,0,b,0,3)的意思是从a数组的0位开始长度为3的一群数拷贝到b数组从0开始的位置上，如果越界，会抛出异常
~~具体复杂度应该是O(n)但是比手写复制跑的快。我揣测~~

# 多维数组 and (for each 语句)
```java
public class Main {
    public static void main(String[] args) {
        int [][] a;//定义多维数组
        a = new int[4][];//定义第一维大小
        a[0] = new int[1];
        a[1] = new int[2];
        a[2] = new int[3];
        a[3] = new int[4];//定义第二维不规则大小
        a[0][0] = 1;
        a[1][0] = 2;
        for(int [] i:a){
            for(int j :i)
                System.out.printf("%d ",j);
        }//for each 语句
        System.out.println();
    }
}
```
这里面二维数组每一维的大小都是可变的
for each语句的格式如下
for(数据类型 变量:集合)

# 相关练习
实现冒泡排序，快速排序
