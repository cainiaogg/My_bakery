title: Java基本语言_Unit2
categories: 从零一起学Java
date: 2016-01-17 11:27:49
---
**我也是从零开始哦，把你带歪了别怪我...** 
<!--more-->
一个.java文件中只能有一个public class ，但是可以有多个class
## 标识符
这个和C语言差不多，由大小写字母，数字，下划线和$组成，但是不能以数字开头。推荐从头养成良好的命名习惯。

*   包名：使用小写字母（包就是和c++头文件差不多的东西）
*   类名和接口名：所有单词的首字母大写
*   方法名：第一个单词首字母小写，其他单词的首字母大写
*   变量名：成员变量和方法相同，局部变量全部使用小写
*   常量名：全部使用 大写，最好使用下划线分割单词
例如：
```java
import java.math.*; //这个就是从java.math里包括所有成员，要使用小写字母，和python差不多，python 语法是from ... import *

class Gao {
    int judgeGao;//这个成员变量，首字母小写其他单词首字母大写
    public void gao_Game(int  game){
        int cc;//局部变量就是成员函数里的变量，函数没了，他也就没了，全部小写
        System.out.println(game);
    }//我觉得这里的方法就是和c++里面成员函数差不多的东西，首字母小写
}//这个是类，Gao的首字母大写咯
public class Main {

    public static void main(String[] args) {
        final int XI_GUA = 100;//这个是定义常量，全部大写，最好使用下划线分隔单词
        Gao a = new Gao();
        a.gao_Game(XI_GUA);//java里面基本类型传递是值传递，对象的传递是引用，这个以后再说
        System.out.println("hello world\n");
    }
}

```

## 关键字
先知道public，protected，private，class，几个关键字。剩下的，有流程控制关键字比如循环判断选择等遇到了再说。
数据类型和c++基本一致。
有int short long float double char byte，他这里面的布尔是boolean，int 32位，long 64位
//是注释和c++一样的，在idea里，你可以选中需要注释的区域按ctrl+/注释或者取消注释
```java
public class Main {
    public static void main(String[] args) {
        System.out.println(0x10);
        System.out.println(010);
    }
}
```
上述程序结果:
>16
>8

### 进制
0x开头表示这个数是16进制下的形式
0开头表示这个数是8进制下的形式
至于怎么输出8进制或者16进制的方法，这个还没看到。

### 基本数据类型
float a = 1.23f;
定义的时候float必须要有f，浮点型默认是double强制转换成float可能会丢失
double a = 1.23
可要可不要，默认是double
int a = 1
long a = 1
这样写没关系
long a = 11111111111L
数字超过int的时候末尾应当加L
```java
public class Main {
    public static void main(String[] args) {
        char a = 97;
        System.out.println(a);
    }
}
```
输出结果：
a
这点和c++一样，可以用ascii码。

### 转义字符
\n 换行
\t teb
\b 退格
等等，类似c++

### 数据类型转换
类似c++;
```java
public class Main {
    public static void main(String[] args) {
        char a = 'a';
        int b = a;
        System.out.println((char)b);
        System.out.println(b);
        System.out.println(a);
    }
}
```
输出结果：
a
97
a
要注意一点
在这里面的 boolean t = true;
只能这样书写不能写成boolean t = 1;

## 运算符
&&，||，+，-，*，/，&，|，^，<<，>>，~，！，(1>2)?1:2应该是通用的吧。++，--，这个你应该天天用。运算优先级看感觉来吧。

## 例题
1.输出123123\*54312363的结果
2.输出 123\*123>25\*103 && 123\*97 || 2>1 的结果
3.输出16进制下的123123abc 在 10进制下的表示形式



