title: Java控制流程语句_Unit3
date: 2016-01-18 07:39:38
categories: 从零一起学Java
---

# 作用域
定义一个变量作用于大括号内以及定义变量位置之后。
<!--more-->
示例：
```java
public class Main {
    public static void main(String[] args) {
        int testA = 10;
        {
            //System.out.println(testB); 这句也是不合法的，作用域应该在定义这个变量之后。
            int testB = 10;
        }
        System.out.println(testA);
        //System.out.println(testB); 这句是不合法的，testB的作用域只在大阔号内
    }
}
```

# 条件语句
## if条件语句
>if (条件) {
>  
>} 
>else {
>  
>}
>注意条件的值一定是boolean类型，无论是一个方法返回值或者一个表达式的值

## switch条件语句
>swich(){
    case value1:
        //
        break;
    case value2:
        //
        break;
    default:
        //
>}
>和c++一样，break的问题自己注意下。

示例：
```java
public class Main {
    static boolean gaoTest(){
        return true;
    }// main 函数里只能调用静态方法，这个函数默认类型是default，其他的三个public，protected，private都和c++一样，default是同一个包内的可以访问。
    public static void main(String[] args) {
        int testA = 100;
        int testB = 200;
        switch(testA){
//            case testA: 这样是不行的，case后面只能接常量表达式
            case 100: {
                System.out.println(100);
                break;
            }
            case 200:
                System.out.println(200);
                break;
            default:
                System.out.println(300);
        }
        if (testA > testB) {
            System.out.println("testA > testB");
        }
        else {
            System.out.println("testB > testA");
        }
        if (gaoTest()) {
            System.out.println("SSSSSSSSSSSS");
        }
    }
}
```
结果：
>testB > testA
>SSSSSSSSSSSS

# 循环语句
## while循环语句
>while(){
    
>}
## do-while循环语句
>do{
    
>}
>while()
## for循环语句
>for(int i = 0; i < 100; i++){
    
>}

示例：
```java
public class Main {
    static boolean gaoTest(){
        return true;
    }// main 函数里只能调用静态方法，这个函数默认类型是default，其他的三个public，protected，private都和c++一样，default是同一个包内的可以访问。
    public static void main(String[] args) {
        int ansCnt = 0;
        for (int i = 0; i < 100; i++){ //这里和c++一样，初始化条件定义的变量作用域只于这个循环体内
            ansCnt += i;
        }
        System.out.println(ansCnt);
        ansCnt = 0;
        int i = 1;
        while(i < 100){
            ansCnt += i;
            i++;
        }
        System.out.println(ansCnt);
        ansCnt = 0;
        i = 0;
        do{
            i++;
            ansCnt += i;
        }while(i < 99);
        System.out.println(ansCnt); //这里我故意把i++写在前面，估计你也不太常用 do-while，注意下就好。
    }
}
```
结果：
4950
4950
4950

# 跳转语句
## break跳出
第一个用法和c++一样，直接跳出当前循环体
第二个在java里可以对块进行标记，并直接跳出块。
格式如下
>标记：{    
>}
>break

```java
public class Main {
    public static void main(String[] args) {
        first:{
            second:{
                third:{
                    for(int i = 0; i < 10; i++) {
                        if (i==3)
                            break second;//跳出第二个块回到第一个块
                        System.out.println(i);
                    }
                }
                System.out.println("second");
            }
            System.out.println("first");
        }
    }
}
```
结果：
>0
>1
>2
>first
## continue语句
类似上面的break，也可以直接继续跳过当前步骤进入下一个循环或者块内
## return语句
和c++的函数return基本一致。

# 例题
1.输出9*9乘法表
先这一个，等后面i/o模块学下，你可以到这些个网站练练手。
[Aoj](http://icpc.ahu.edu.cn/OJ/)
[Codeforces](http://codeforces.com/)
[Hdu](http://acm.hdu.edu.cn/)
